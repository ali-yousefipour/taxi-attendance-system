class ReportStatusLog extends Model
{
    protected $fillable = [
        'report_id',
        'user_id',
        'action'
    ];
}
