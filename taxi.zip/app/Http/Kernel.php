'role' => \App\Http\Middleware\RoleMiddleware::class,
